#Example Package
This Package allows you to predict user salary based on number of years of experience.
